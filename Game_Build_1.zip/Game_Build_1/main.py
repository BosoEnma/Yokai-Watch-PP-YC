import pygame
from main_2 import L
pygame.init()
screen = pygame.display.set_mode((1080,720),pygame.RESIZABLE)
clock = pygame.time.Clock()
pygame.display.set_caption("Yokai Watch PP Showcase")

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit()


    screen.fill('white')
    #Finishing the Actions then skipping to the next, it will write if all the actions are done in the .Jupiter file. If Slide = False it will write Slide animation is done and the slide animation will stop playing.
    Slide = True
    if Slide == True:
        L().Link
    else:
        file = open("Log.JUPITER","w")
        filewrite1 = file.write("Slide Animation is done.\n")


    pygame.display.update()
    clock.tick(30)