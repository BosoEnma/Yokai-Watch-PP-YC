With this app yo can quickly and effectivly make yokai, and their animations.
Note that this is meant to showcase them not be a full on game.