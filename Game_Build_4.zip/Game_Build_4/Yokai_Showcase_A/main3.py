from Yokai_Showcase_A.Yokai_UI_Play import SecoundS

class L2:
    def __init__(self):
        #SDS = Secound Display Screen, Secound animation
        self.SDS = SecoundS().Play2U(),SecoundS().Play_2()