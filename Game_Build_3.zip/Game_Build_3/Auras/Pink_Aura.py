class YAPK(pygame.sprite.Sprite):
    def __init__(self,pos_x,pos_y):
        super().__init__()
        self.PinkAnimate = True
        self.sprites = []
        self.loadpink_1 = pygame.image.load("All_Ef_Auras/Aura_Pink_1.Mana").convert_alpha()
        self.loadpink_2 = pygame.image.load("All_Ef_Auras/Aura_Pink_2.Mana").convert_alpha()
        self.loadpink_3 = pygame.image.load("All_Ef_Auras/Aura_Pink_3.Mana").convert_alpha()
        self.loadpink_4 = pygame.image.load("All_Ef_Auras/Aura_Pink_4.Mana").convert_alpha()
        self.loadpink_5 = pygame.image.load("All_Ef_Auras/Aura_Pink_5.Mana").convert_alpha()
        self.sprites.append(self.loadpink_1)
        self.sprites.append(self.loadpink_2)
        self.sprites.append(self.loadpink_3)
        self.sprites.append(self.loadpink_4)
        self.sprites.append(self.loadpink_5)

        self.current_sprite = 0
        self.image = self.sprites[self.current_sprite]

        self.rect = self.image.get_rect()
        self.rect.topleft = [0, 0]

    def update(self):
        if self.PinkAnimate == True:
            self.current_sprite += 1

        if self.current_sprite >= len(self.sprites):
            self.current_sprite = 0

        self.image = self.sprites[int(self.current_sprite)]
PA = pygame.sprite.Group()
PG = YAPK(0,0)
PA.add(PG)
class PAU:
    def PAu(self):
        PA.draw(screen)
        PA.update()