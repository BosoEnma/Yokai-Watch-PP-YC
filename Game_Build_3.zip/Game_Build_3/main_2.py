from Slide_Anim import S
from Slide_Anim import ITM
#, S().OV_Y, S().LB, S().P, S().YN, ITM().MLI()

class L:
    def __init__(self):
        self.SA = S().BG_I, ITM().MLI()
    def M(self):
        ITM().MLI()
    def play_Sound(self):
        S_SA = S().S()