import pygame
screen = pygame.display.set_mode((1080,720))


class S:
    def __init__(self):
        #I = Image, Y = Yokai, OV = Overlay, L = Logo, P = Puni, N = Name, sp = Sound_play
        self.BG_I = pygame.image.load("Yokai_SlideShow/BG.YO").convert_alpha()
        self.BG_RI = pygame.transform.scale(self.BG_I, (1080, 720)).convert_alpha()
        screen.blit(self.BG_RI, (0, 0))



    def S(self):
        pygame.mixer.music.load("Music/Slide_Audio/Slide_Ring.m4")
        pygame.mixer.music.play(1)

BG_Y = pygame.image.load("Yokai_SlideShow/Yokai_Shadow_B.YO").convert_alpha()
BG_YR = BG_Y.get_rect(topleft=(0,0))
OV_Y = pygame.image.load("Yokai_SlideShow/Yokai_Art.YO").convert_alpha()
OV_YR = OV_Y.get_rect(topleft=(0,0))
#ITM = Images that move


class ITM:
    def MLI(self):
        screen.blit(BG_Y,BG_YR)
        BG_YR.x -= 2
        screen.blit(OV_Y, OV_YR)
        OV_YR.x += 1
        LB = pygame.image.load("Yokai_SlideShow/Brave.YO").convert_alpha()
        screen.blit(LB, (0, 0))
        P = pygame.image.load("Yokai_SlideShow/Yokai_Puni.YO").convert_alpha()
        screen.blit(P, (0, 0))
        YN = pygame.image.load("Yokai_SlideShow/Yokai_Text_Name.YO").convert_alpha()
        screen.blit(YN, (0, 0))


#self.OV_Y = pygame.image.load("Yokai_SlideShow/Yokai_Art.YO").convert_alpha()
#screen.blit(self.OV_Y, (0, 0))
#self.LB = pygame.image.load("Yokai_SlideShow/Brave.YO").convert_alpha()
#screen.blit(self.LB, (0, 0))
#self.P = pygame.image.load("Yokai_SlideShow/Yokai_Puni.YO").convert_alpha()
#screen.blit(self.P, (0, 0))
#self.YN = pygame.image.load("Yokai_SlideShow/Yokai_Text_Name.YO").convert_alpha()
#screen.blit(self.YN, (0, 0))