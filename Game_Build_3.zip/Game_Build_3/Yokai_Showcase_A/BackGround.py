import pygame
pygame.init()
screen = pygame.display.set_mode((1080,720))