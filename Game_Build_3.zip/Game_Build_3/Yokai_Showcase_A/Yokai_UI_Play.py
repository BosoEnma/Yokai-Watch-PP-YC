import pygame
pygame.init()
screen = pygame.display.set_mode((1080,720))

#Creating the area where the Yokai Stats and things will e contained in.
All_UI_Play_B = pygame.image.load("Yokai_SlideShow/BG.YO").convert_alpha()
All_UI_Play_BR = pygame.transform.scale(All_UI_Play_B,(480,720)).convert_alpha()
All_UI_Play_BR.fill('black')

Screen_Border = pygame.image.load("Yokai_Showcase_A/Yokai_SetupOV/All_Ef_Play_BG.DOG").convert_alpha()
#These will go under and I will have to define another def so I can switch between Animations without breaking
Fact_Border = pygame.image.load("Yokai_Showcase_A/Yokai_SetupOV/Fact_Border.DOG").convert_alpha()
Fact_Border_Text = pygame.image.load("Yokai_Showcase_A/Yokai_SetupOV/Fact_Border_Text.DOG").convert_alpha()
Skinny_Line = pygame.image.load("Yokai_Showcase_A/Yokai_SetupOV/Skinny_Line.DOG").convert_alpha()
TopSlide = pygame.image.load("Yokai_Showcase_A/Yokai_SetupOV/Top_Slide.DOG").convert_alpha()
Whisper_Pointers = pygame.image.load("Yokai_Showcase_A/Yokai_SetupOV/Whisper_Pointers.DOG").convert_alpha()
Yokai_Info_1 = pygame.image.load("Yokai_Showcase_A/Yokai_SetupOV/Yokai_Info_1.DOG").convert_alpha()
Yokai_Info_2 = pygame.image.load("Yokai_Showcase_A/Yokai_SetupOV/Yokai_Info_2.DOG").convert_alpha()
Yokai_Name = pygame.image.load("Yokai_Showcase_A/Yokai_SetupOV/Yokai_Name.DOG").convert_alpha()
ZZIcon = pygame.image.load("Yokai_Showcase_A/Yokai_SetupOV/ZZ_Icon.DOG").convert_alpha()
ZZZIcon = pygame.image.load("Yokai_Showcase_A/Yokai_SetupOV/ZZZ_Icon.DOG").convert_alpha()
Yokai_Shadow = pygame.image.load("Yokai_Showcase_A/Yokai_SetupOV/Yokai_Shadow_B.YO").convert_alpha()
Yokai_Art = pygame.image.load("Yokai_Showcase_A/Yokai_SetupOV/Yokai_Art.YO").convert_alpha()

class SecoundS:
    def Play_2(self):
        screen.blit(Screen_Border,(0,0))
        screen.blit(ZZIcon, (0, 0))
        screen.blit(Yokai_Name, (0, 0))

    def Play2U(self):
        EnmaABrave = [249,89,87]
        Grey = [214,214,214]
        screen.fill(EnmaABrave)
        pygame.draw.rect(screen, Grey, pygame.Rect(400, -20, 750, 750))
        Yokai_ShadowR = pygame.transform.smoothscale(Yokai_Shadow,(1500,1000))
        screen.blit(Yokai_ShadowR,(450,0))
        screen.blit(Yokai_Art,(-550,0))
        screen.blit(TopSlide,(0,0))
        screen.blit(Fact_Border,(0,0))
        screen.blit(Fact_Border_Text,(0,0))
        screen.blit(Whisper_Pointers,(0,0))
        screen.blit(Skinny_Line,(0,0))
        screen.blit(Yokai_Info_1,(0,0))
        screen.blit(Yokai_Info_2,(0,0))



