import pygame
from main_2 import L
from Yokai_Showcase_A.main3 import L2
from sys import *
pygame.init()
screen = pygame.display.set_mode((1080,720))
clock = pygame.time.Clock()
pygame.display.set_caption("Yokai Watch PP Showcase")
icon = pygame.image.load("Icon.ico").convert_alpha()
pygame.display.set_icon(icon)

L().play_Sound()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()

    screen.fill('white')
    #Finishing the Actions then skipping to the next, it will write if all the actions are done in the .Jupiter file. If Slide = False it will write Slide animation is done and the slide animation will stop playing.
    Slide = True
    #It vanishes after 3/2 secounds
    Start_Time = 0
    current_time = pygame.time.get_ticks() - Start_Time
    print(current_time)
    if current_time >= 3600:
        Slide = False
        L2().SDS
    if Slide == True:
        L().SA
    else:
        file = open("Log.JUPITER","w")
        filewrite1 = file.write("Slide Animation is done.\n")




    pygame.display.update()
    clock.tick(30)