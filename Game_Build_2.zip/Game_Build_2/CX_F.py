import cx_Freeze
executables = [cx_Freeze.Executable("main.py")]

cx_Freeze.setup(
    name = "Yokai Watch Beta 1",
    options={"build_.exe": {"packages":["pygame"],
                            "include_files":["Log.JUPITER","main_2.py","Slide_Anim.py","Readme.txt","Yokai_SlideShow/BG.YO","Yokai_SlideShow/Brave.YO","Yokai_SlideShow/Test_Image_Reference.SID","Yokai_SlideShow/Yokai_Art.YO","Yokai_SlideShow/Yokai_Puni.YO","Yokai_SlideShow/Yokai_Shadow.YO","Yokai_SlideShow/Yokai_Text_Name.YO","Yokai's/Enma_Kantoku.YO","Yokai's/Yokai_Center.YO","Yokai's/Yokai_Center_BG.YO"]}}
)