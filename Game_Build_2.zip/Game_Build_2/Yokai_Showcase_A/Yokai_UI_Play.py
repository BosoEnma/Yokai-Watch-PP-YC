import pygame
pygame.init()
screen = pygame.display.set_mode((1080,720))

#Creating the area where the Yokai Stats and things will e contained in.
All_UI_Play_B = pygame.image.load("Yokai_SlideShow/BG.YO").convert_alpha()
All_UI_Play_BR = pygame.transform.scale(All_UI_Play_B,(480,720)).convert_alpha()
All_UI_Play_BR.fill('black')

class SecoundS:
    def Play_2(self):
        screen.blit(All_UI_Play_BR,(0,0))
