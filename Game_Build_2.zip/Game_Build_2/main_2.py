from Slide_Anim import S
#

class L:
    def __init__(self):
        self.Link = S().BG_I, S().BG_Y, S().OV_Y, S().LB, S().P, S().YN