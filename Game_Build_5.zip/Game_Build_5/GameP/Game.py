import pygame
pygame.init()
screen = pygame.display.set_mode((1280,720))
from Yokai_Stats_A.Yokai_Info_Stats import YokaiD

Game_Boarder = pygame.image.load("GameP/All_Board_Game.PL1").convert_alpha()
Game_BoarderRS = pygame.transform.scale(Game_Boarder,(335,720))
Game_BoarderR = Game_BoarderRS.get_rect(topleft=(147,0))
Game_Boarder_Outline = pygame.image.load("GameP/All_Board_Game_Yokai_Showcase_Border.PL1").convert_alpha()
Game_Boarder_OutlineRS = pygame.transform.smoothscale(Game_Boarder_Outline,(1000,720)).convert_alpha()
Game_Boarder_OutlineR = Game_Boarder_OutlineRS.get_rect(topleft=(147,0))
Ref = pygame.image.load("Yokai_Stats_A/All_Reference_image.png").convert_alpha()
RefR = pygame.transform.smoothscale(Ref,(1280,720)).convert_alpha()
AWB = [119,255,255]
All_White_1 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_1.YO").convert_alpha()
All_White_2 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_2.YO").convert_alpha()
All_White_3 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_3.YO").convert_alpha()
All_White_4 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_4.YO").convert_alpha()
All_White_5 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_5.YO").convert_alpha()
All_White_6 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_6.YO").convert_alpha()
All_White_7 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_7.YO").convert_alpha()
All_White_8 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_8.YO").convert_alpha()
All_White_9 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_9.YO").convert_alpha()
All_White_0 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_0.YO").convert_alpha()
All_White_QM = pygame.image.load("Yokai_Stats_A/Numbers/All_White_QuestionMark.YO").convert_alpha()
All_White_LV = pygame.image.load("Yokai_Stats_A/Numbers/All_White_LV.YO").convert_alpha()

All_Blue_1 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_1.YO").convert_alpha()
All_Blue_2 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_2.YO").convert_alpha()
All_Blue_3 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_3.YO").convert_alpha()
All_Blue_4 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_4.YO").convert_alpha()
All_Blue_5 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_5.YO").convert_alpha()
All_Blue_6 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_6.YO").convert_alpha()
All_Blue_7 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_7.YO").convert_alpha()
All_Blue_8 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_8.YO").convert_alpha()
All_Blue_9 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_9.YO").convert_alpha()
All_Blue_0 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_0.YO").convert_alpha()
All_Blue_QM = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_QuestionMark.YO").convert_alpha()
All_Blue_LV = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_LV.YO").convert_alpha()



class Game:
    def __init__(self):
        self.All_Game_Border = screen.blit(Game_BoarderRS,Game_BoarderR)
        self.All_Outline_Border = screen.blit(Game_Boarder_OutlineRS,(23,0))
        #self.Test = screen.blit(RefR,(0,0))
        #self.one = YokaiD().ALL1HP
        #self.one = YokaiD().ALL1Attack
        self.Stat = YokaiD().YSB
        #self.YP = YokaiD().YPoint
