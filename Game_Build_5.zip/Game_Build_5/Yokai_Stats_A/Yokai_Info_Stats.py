import pygame
screen = pygame.display.set_mode((1280,720))

HP = "1456"

Attack = "1427"

LV90 = "90"
LV80 = "80"
LV70 = "70"
LV60 = "60"
LV50 = "50"

Max = True
LV10 = False
LV20 = False
LV30 = False
LV40 = False
LV50 = False
LV60 = False
LV70 = False
LV80 = False

Font = pygame.font.Font("Fonts/text.FNT",100)
class YokaiD:
    def __init__(self):
        self.white = [255,255,255]
        self.BG = pygame.image.load("Yokai_Stats_A/All_BG/ypad_bg_ypad01_01.YO").convert_alpha()
        self.BGR = pygame.transform.smoothscale(self.BG,(335,720)).convert_alpha()
        #self.Name = Font.render("Overseer Enma", True, self.white)
        #self.RN = screen.blit(self.Name,(0,0))
        self.YP = pygame.image.load("Yokai_Stats_A/YMYPS.YO").convert_alpha()
        self.Y = pygame.image.load("Yokai_Stats_A/OVENMA/Over_Enma_Test.YO").convert_alpha()
        self.YN = pygame.image.load("Yokai_Stats_A/Y_Name.YO").convert_alpha()
        self.ENMA = pygame.image.load("Yokai_Stats_A/Tribes/Enma_YS.TRB").convert_alpha()
        self.ENMAR = pygame.transform.smoothscale(self.ENMA,(30,30)).convert_alpha()
        self.Fullr = pygame.image.load("Yokai_Stats_A/Button/Soul_Gauge_Full.YO").convert_alpha()
        self.full = pygame.transform.smoothscale(self.Fullr,(70,19))

        All_Stat_Border = pygame.image.load("Yokai_Stats_A/OVENMA/Over_Enma_Stats.YO").convert_alpha()
        All_White_1 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_1.YO").convert_alpha()
        All_White_1R = pygame.transform.smoothscale(All_White_1,(15,20)).convert_alpha()
        All_White_2 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_2.YO").convert_alpha()
        All_White_2R = pygame.transform.smoothscale(All_White_2, (15, 20)).convert_alpha()
        All_White_3 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_3.YO").convert_alpha()
        All_White_3R = pygame.transform.smoothscale(All_White_3, (15, 20)).convert_alpha()
        All_White_4 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_4.YO").convert_alpha()
        All_White_4R = pygame.transform.smoothscale(All_White_4, (15, 20)).convert_alpha()
        All_White_5 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_5.YO").convert_alpha()
        All_White_5R = pygame.transform.smoothscale(All_White_5, (15, 20)).convert_alpha()
        All_White_6 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_6.YO").convert_alpha()
        All_White_6R = pygame.transform.smoothscale(All_White_6, (15, 20)).convert_alpha()
        All_White_7 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_7.YO").convert_alpha()
        All_White_7R = pygame.transform.smoothscale(All_White_7, (15, 20)).convert_alpha()
        All_White_8 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_8.YO").convert_alpha()
        All_White_8R = pygame.transform.smoothscale(All_White_8, (15, 20)).convert_alpha()
        All_White_9 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_9.YO").convert_alpha()
        All_White_9R = pygame.transform.smoothscale(All_White_9, (15, 20)).convert_alpha()
        All_White_0 = pygame.image.load("Yokai_Stats_A/Numbers/All_White_0.YO").convert_alpha()
        All_White_0R = pygame.transform.smoothscale(All_White_0, (15, 20)).convert_alpha()
        All_White_QM = pygame.image.load("Yokai_Stats_A/Numbers/All_White_QuestionMark.YO").convert_alpha()
        All_White_LV = pygame.image.load("Yokai_Stats_A/Numbers/All_White_LV.YO").convert_alpha()

        All_Blue_1 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_1.YO").convert_alpha()
        All_Blue_1R = pygame.transform.smoothscale(All_Blue_1, (15, 20)).convert_alpha()
        All_Blue_2 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_2.YO").convert_alpha()
        All_Blue_2R = pygame.transform.smoothscale(All_Blue_2, (15, 20)).convert_alpha()
        All_Blue_3 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_3.YO").convert_alpha()
        All_Blue_3R = pygame.transform.smoothscale(All_Blue_3, (15, 20)).convert_alpha()
        All_Blue_4 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_4.YO").convert_alpha()
        All_Blue_4R = pygame.transform.smoothscale(All_Blue_4, (15, 20)).convert_alpha()
        All_Blue_5 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_5.YO").convert_alpha()
        All_Blue_15R = pygame.transform.smoothscale(All_Blue_5, (15, 20)).convert_alpha()
        All_Blue_6 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_6.YO").convert_alpha()
        All_Blue_6R = pygame.transform.smoothscale(All_Blue_6, (15, 20)).convert_alpha()
        All_Blue_7 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_7.YO").convert_alpha()
        All_Blue_7R = pygame.transform.smoothscale(All_Blue_7, (15, 20)).convert_alpha()
        All_Blue_8 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_8.YO").convert_alpha()
        All_Blue_8R = pygame.transform.smoothscale(All_Blue_8, (15, 20)).convert_alpha()
        All_Blue_9 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_9.YO").convert_alpha()
        All_Blue_9R = pygame.transform.smoothscale(All_Blue_9, (15, 20)).convert_alpha()
        All_Blue_0 = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_0.YO").convert_alpha()
        All_Blue_0R = pygame.transform.smoothscale(All_Blue_0, (15, 20)).convert_alpha()
        All_Blue_QM = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_QuestionMark.YO").convert_alpha()
        All_Blue_LV = pygame.image.load("Yokai_Stats_A/Numbers/All_Blue_LV.YO").convert_alpha()


        self.BackG = screen.blit(self.BGR, (146, 0))

        #if HP == "1456":
            #Add 16 every number, X always starts at 316, 332, 348,364
            #self.ALL1HP = screen.blit(All_White_1R, (316, 416)),screen.blit(All_White_4R,(332,416)),screen.blit(All_White_5R,(348,416)),screen.blit(All_White_6R,(364,417))
        #if Attack == "1427":
            #self.ALL1Attack = screen.blit(All_White_1R, (316,444)),screen.blit(All_White_4R, (332,445)),screen.blit(All_White_2R, (348,444)),screen.blit(All_White_7R, (364,446))

        self.YSB = screen.blit(All_Stat_Border,(10,50))
        self.YPoint = screen.blit(self.YP,(0,0))
        self.YokaiENMY = screen.blit(self.Y,(40,0))
        self.YN = screen.blit(self.YN,(0,0))
        self.T=E = screen.blit(self.ENMAR,(398,465))
        self.Full = screen.blit(self.full,(173,14))

