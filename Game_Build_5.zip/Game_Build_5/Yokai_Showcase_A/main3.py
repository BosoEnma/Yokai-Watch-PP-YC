from Yokai_Showcase_A.Yokai_UI_Play import SecoundS
from GameP.Game import Game
from Yokai_Stats_A.Yokai_Info_Stats import YokaiD

class L2:
    def __init__(self):
        #SDS = Secound Display Screen, Secound animation
        self.SDS = SecoundS().Play2U(),SecoundS().Play_2()
    def Game(self):
        Game().All_Game_Border
        Game().All_Outline_Border
        Game().one
        Game().Stat
