import pygame
pygame.init()
screen = pygame.display.set_mode((1280,720))